id	username	first_name	last_name	email	password	is_staff	is_active	is_superuser	last_login	date_joined	status	email_key	avatar_type	country	show_country	date_of_birth	interesting_tags	ignored_tags	email_tag_filter_strategy	display_tag_filter_strategy	consecutive_days_visit_count
265520	Jonghoon			jonghoon.ryu@gmail.com		0	1	0	2014-08-05 16:29:43	2012-08-16 21:17:36		NULL			0	NULL			0	0	0
3817068	GineannK			gineann.karzai@lntinfotech.com		0	1	0	2014-08-18 08:35:21	2014-03-18 07:56:17		NULL			0	NULL			0	0	0
1646583	dammala			anu.dammalap@gmail.com		0	1	0	2014-08-17 16:56:19	2013-05-01 14:38:01		NULL			0	NULL			0	0	0
3464706	akhilsourabh			sourabhakhil7@gmail.com		0	1	0	2014-08-10 07:55:47	2014-02-12 13:19:59		NULL			0	NULL			0	0	0
455224	sabeeee			sabeeh31@gmail.com		0	1	0	2014-04-12 10:46:21	2012-09-17 20:26:40		NULL			0	NULL			0	0	0
